// import logo from './logo.svg';
import './App.css';
import FuncJSXnguyenleducthanh from './compenents/FuncJSXnguyenleducthanh';
import Classnguyenleducthanh from './compenents/Classnguyenleducthanh';

function App() {
  return (
    <section className="App">
      <h1>Demo JSX</h1>
      <FuncJSXnguyenleducthanh />
      <FuncJSXnguyenleducthanh fullname="Nguyen Le Duc Thanh" age={20} /> 
      <Classnguyenleducthanh />
      <hr />
      <Classnguyenleducthanh info="hoc reactjs" time={11} /> 
    </section>
  );
}

export default App;
