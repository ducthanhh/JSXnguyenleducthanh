import React from 'react';

export default function FuncJSXnguyenleducthanh(props) {
    const user = {
        name: "Nguyen Le Duc Thanh",
        age: 20
    };

    return (
        <div>
            <h2>Function Component Demo</h2>
            <h3>
                Welcome to, {user.name} - {user.age}
            </h3>
            <hr/>
            <h3>Props:
                <br/>Fullname: {props.fullname}
                <br/>Age: {props.age}
            </h3>
        </div>
    );
}
