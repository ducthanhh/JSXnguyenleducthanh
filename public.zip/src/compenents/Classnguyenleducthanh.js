import React, { Component } from "react";

class Classnguyenleducthanh extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fullname: "Nguyen Le Duc Thanh",
            class: "k22cntt3"
        };
    }

    users = {
        name: "Nguyen Le Duc Thanh",
        age: 20
    };

    handleChange = () => {
        this.setState({
            fullname: "Chach"
        });
    };

    render() {
        return (
            <div>
                <h1>This is class component</h1>
                {this.users.name} - {this.users.age}
                <h2>Hello {this.props.username}! Welcome to {this.props.name}</h2>
                <hr />
                <h3>Info: {this.props.info}</h3>
                <h3>Time: {this.props.time}</h3>
                <hr />
                <h3>State:
                    Fullname: {this.state.fullname} -
                    Class: {this.state.class}
                </h3>
                <button onClick={this.handleChange}>Change name</button>
            </div>
        );
    }
}

export default Classnguyenleducthanh;
